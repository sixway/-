import logging
from flask_script import Manager
from KyjdtApp import create_app

logging.basicConfig(
    level=logging.ERROR,
    format="%(asctime)s %(levelname)s %(module)s %(funcName)s %(message)s"
)

app = create_app()
manager = Manager(app)


if __name__ == "__main__":
    manager.run()