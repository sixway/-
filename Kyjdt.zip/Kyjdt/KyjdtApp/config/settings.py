DEBUG = True

SQLALCHEMY_DATABASE_URI = 'mysql+cymysql://root:123456@localhost:3306/qi_men_dun_jia'

SECRET_KEY = 'c6ce933e-5f91-4ec8-ab98-23fa790ec5d0-fb336282-d18e-49f5-b949-a7f53e3396d1'

# 开启数据库查询性能测试
SQLALCHEMY_RECORD_QUERIES = True

# 性能测试的阀值
DATABASE_QUERY_TIMEOUT = 0.5

SQLALCHEMY_TRACK_MODIFICATIONS = False

WTF_CSRF_CHECK_DEFAULT = False

SQLALCHEMY_ECHO = True

REDIS_URL = "redis://@127.0.0.1:6379/1"
ORDER_REDIS_URL = "redis://@127.0.0.1:6379/0"
CONFIG_REDIS_URL = "redis://@127.0.0.1:6379/0"

# 微信公众号信息
WX_APPID = 'wx6951c959ca2737ec'
WX_SECRET = '5bf47e12ac59d46ba0d24e2d0541fd06'