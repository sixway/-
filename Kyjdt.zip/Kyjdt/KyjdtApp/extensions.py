from contextlib import contextmanager
from flask_sqlalchemy import SQLAlchemy as _SQLAlchemy
from flask import current_app


__all__ = ['db']

class SQLAlchemy(_SQLAlchemy):
    @contextmanager
    def auto_commit(self, throw=True):
        try:
            yield
            self.session.commit()
        except Exception as e:
            self.session.rollback()
            current_app.logger.exception('%r' % e)
            if throw:
                raise e

db = SQLAlchemy()