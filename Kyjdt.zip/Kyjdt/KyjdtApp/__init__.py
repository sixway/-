from flask import Flask, render_template
from .extensions import db


def register_web_blueprint(app):
    from KyjdtApp.controllers import web
    app.register_blueprint(web)


def create_app():
    app = Flask(__name__)
    # 导入注册文件
    app.config.from_object("KyjdtApp.config.settings")

    # 注册SQLALchemy
    db.init_app(app)

    # 注册蓝图
    register_web_blueprint(app)
    configure_errorhandlers(app)
    return app


def configure_errorhandlers(app):
    @app.errorhandler(404)
    def page_not_found(error):
        return render_template("error/404.html")

    @app.errorhandler(500)
    def server_error(error):
        return render_template("error/500.html")