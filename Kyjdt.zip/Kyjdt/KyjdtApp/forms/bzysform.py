from wtforms import StringField, IntegerField, Form, DateField
from wtforms.validators import Length, Regexp, DataRequired, InputRequired


class OrderPayForm(Form):
    user_name = StringField('愿主姓名', validators=[
        DataRequired("请输入姓名"),
        Length(min=2, max=5, message='姓名长度必须在2到5个字符之间'),
        Regexp('^[\u4E00-\u9FA5]+$', message='请输入中文')
    ])
    gender = StringField('性别', validators=[DataRequired("请选择性别")])
    product_name = StringField('产品名字', validators=[DataRequired("必填")])
    product_id = StringField('产品编号', validators=[DataRequired("必填")])
    birth_date = DateField('出生日期', validators=[DataRequired("必填")])
    birth_time = IntegerField('出生时辰', validators=[InputRequired("必填")])
    birth_date_lunar = StringField('农历出生时辰', validators=[DataRequired("必填")])
    cid = StringField('渠道号', validators=[DataRequired("必填")])
    wuxing = StringField('五行', validators=[DataRequired("必填"), Regexp(
        '^[\u4E00-\u9FA5]+$', message='请输入中文')])
    bazi = StringField('八字', validators=[DataRequired("必填"), Regexp(
        '^[\u4E00-\u9FA5]+$', message='请输入中文')])
