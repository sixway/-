from enum import Enum


class PendingStatus(Enum):
    """交易状态"""
    waiting = 0
    success = 1

    @classmethod
    def pending_str(cls, status):
        key_map = {
            cls.waiting: "等待支付",
            cls.success: "支付成功"
        }
        return key_map[status]
