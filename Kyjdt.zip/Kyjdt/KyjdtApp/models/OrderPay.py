from sqlalchemy import Column, Integer, String, Text, Float, DateTime, Date, SmallInteger

from KyjdtApp.libs.enums import PendingStatus
from .base import Base


class OrderForm(Base):
    __tablename__ = "order_form"
    id = Column(Integer, primary_key=True, unique=True, autoincrement=True)
    cid = Column(String(20), nullable=False, default="0")
    cookies = Column(String(50), nullable=False, default="0")
    order_num = Column(String(50), nullable=False)
    product_name = Column(String(30), nullable=False, default="八字运势")
    product_id = Column(SmallInteger, nullable=False, default=1001)
    user_name = Column(String(60), nullable=False)
    _pay_state = Column('pay_state', SmallInteger, nullable=False, default=0)
    gender = Column(SmallInteger, nullable=False, default=0)
    birth_date = Column(Date, nullable=False)
    birth_date_lunar = Column(String(50), nullable=False)
    birth_time = Column(SmallInteger, nullable=False)
    birth_time_final = Column(SmallInteger, nullable=False)
    bazi = Column(String(30), nullable=False)
    wuxing = Column(String(30), nullable=False)
    ip = Column(String(30), nullable=False)
    ua = Column(String(500), nullable=False)


    @property
    def pay_state(self):
        return PendingStatus(self._pay_state)

    @pay_state.setter
    def pay_state(self, status):
        self._pay_state = status.value


class PayState(Base):
    __tablename__ = "pay_state"
    id = Column(Integer, primary_key=True, unique=True, autoincrement=True)
    cid = Column(String(20), nullable=False)
    product_id = Column(SmallInteger, nullable=False)
    product_name = Column(String(30), nullable=False)
    pay_type = Column(SmallInteger, nullable=False)
    order_num = Column(String(50), nullable=False)
    serial_num = Column(String(64), nullable=False)
    money = Column(Integer, nullable=False, default=3600)
    fee_rate = Column(Float(5,2), nullable=False, default=0.8)
    state = Column(SmallInteger, nullable=False, default=0)
    fcbl = Column(Float(5,2), nullable=False)
    fczt = Column(SmallInteger, nullable=False, default=1)
