from sqlalchemy import Column, TIMESTAMP, text
from ..extensions import db


class Base(db.Model):
    __abstract__ = True
    update_time = Column('update_time', TIMESTAMP(True), nullable=False)
    create_time = Column('create_time', TIMESTAMP(True), nullable=False, server_default=text('NOW()'))

    def set_attrs(self, attrs):
        for key, value in attrs.items():
            if hasattr(self, key) and key != 'id':
                setattr(self, key, value)

