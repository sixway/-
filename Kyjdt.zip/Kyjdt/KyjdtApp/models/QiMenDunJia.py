from sqlalchemy import Column, Integer, String, Text, Float, DateTime, Date
from datetime import datetime
from ..extensions import db


class BiHua(db.Model):
    __tablename__ = "bi_hua"
    num = Column(Integer, primary_key=True, unique=True)
    han_zi = Column(Text, unique=True)


class ChengGu(db.Model):
    __tablename__ = "cheng_gu"
    weight = Column(Integer, primary_key=True, unique=True)
    info1 = Column(String(500), nullable=False)
    info2 = Column(String(500), nullable=False)
    info = Column(String(500), nullable=False)


class CidFccs(db.Model):
    __tablename__ = "cid_fccs"
    cid = Column(String(20), primary_key=True, unique=True)
    fcbl = Column(Float, nullable=False, default=0.8)
    pay_money = Column(Float, nullable=False, default=28.8)


class Dsdp(db.Model):
    __tablename__ = "dsdp"
    id = Column(Integer, primary_key=True, unique=True)
    title = Column(String(20), unique=True, nullable=False)
    info1 = Column(String(500), unique=True)
    info2 = Column(String(500), unique=True)


class EightOne(db.Model):
    __tablename__ = "eight_one"
    id = Column(Integer, primary_key=True, unique=True)
    yy = Column(String(50), index=True, nullable=False)
    jx = Column(String(20), nullable=False)
    ss = Column(String(150), nullable=False)
    info1 = Column(String(500), nullable=False)


class FaCheng(db.Model):
    __tablename__ = "fa_cheng"
    weight = Column(Integer, primary_key=True, unique=True)
    info = Column(String(100))


class JxdjBoy(db.Model):
    __tablename__ = "jxdj_boy"
    id = Column(Integer, primary_key=True, unique=True)
    star = Column(String(10), unique=True, nullable=False)
    info1 = Column(String(100), nullable=False)
    info2 = Column(String(50), nullable=False)
    info3 = Column(String(100), nullable=False)
    state = Column(Integer, nullable=False)


class JxdjGril(db.Model):
    __tablename__ = "jxdj_gril"
    id = Column(Integer, primary_key=True, unique=True)
    star = Column(String(10), unique=True, nullable=False)
    info1 = Column(String(100), nullable=False)
    info2 = Column(String(50), nullable=False)
    info3 = Column(String(100), nullable=False)
    state = Column(Integer, nullable=False)


class LiuShiJiaZi(db.Model):
    __tablename__ = "liu_shi_jia_zi"
    hua_jia_zi = Column(String(30), primary_key=True, unique=True)
    na_yin = Column(String(30), nullable=False)
    miao_shu = Column(Integer)
    fa_cheng_shu = Column(Float)
    cheng_gu = Column(Float)
    info1 = Column(String(300))
    info2 = Column(String(300))
    info3 = Column(String(300))


class Lnyc(db.Model):
    __tablename__ = "lnyc"
    id = Column(Integer, primary_key=True, unique=True)
    state = Column(Integer)
    info = Column(String(100))


class MiaoShu(db.Model):
    __tablename__ = "miao_shu"
    num = Column(Integer, primary_key=True, unique=True)
    info = Column(String(50), nullable=False)


# class OrderForm(db.Model):
#     __tablename__ = "order_form"
#     id = Column(Integer, primary_key=True, unique=True, autoincrement=True)
#     cid = Column(String(20), index=True, nullable=False, default=0)
#     cookies = Column(String(50), index=True, nullable=False)
#     order_num = Column(String(50), unique=True, nullable=False)
#     product_name = Column(String(30), nullable=False, default="八字运势")
#     product_id = Column(Integer)
#     user_name = Column(String(60), nullable=False)
#     pay_state = Column(Integer, default=0, nullable=False)
#     gender = Column(Integer, nullable=False, default=0)
#     birthday = Column(Date, nullable=False)
#     birthday_lunar_calendar = Column(String(50), nullable=False)
#     birthday_hour = Column(Integer, nullable=False)
#     birthday_hour_final = Column(Integer, nullable=False)
#     bazi = Column(String(30), nullable=False)
#     wuxing = Column(String(30), nullable=False)
#     ip = Column(String(30), nullable=False, default="0")
#     source = Column(String(20), nullable=False, default="未知")
#     create_time = Column(DateTime, default=datetime.now)
#     update_time = Column(DateTime, default=datetime.now)
#
#
# class PayState(db.Model):
#     __tablename__ = "pay_state"
#     id = Column(Integer, primary_key=True, unique=True, autoincrement=True)
#     cid = Column(String(20), nullable=False, default=0)
#     product_name = Column(String(30), nullable=False, default="八字运势")
#     product_id = Column(Integer)
#     pay_type = Column(Integer)
#     order_num = Column(String(50), nullable=False)
#     serial_num = Column(String(60), nullable=False)
#     money = Column(Integer, nullable=False, default=2800)
#     fee_rate = Column(Float, nullable=False)
#     state = Column(Integer)
#     fcbl = Column(Float)
#     fczt = Column(Integer)
#     create_time = Column(DateTime, default=datetime.now)
#     update_time = Column(DateTime, default=datetime.now)


class Ri(db.Model):
    __tablename__ = "ri"
    id = Column(Integer, primary_key=True, unique=True, autoincrement=True)
    oneday = Column(String(15), unique=True)
    weight = Column(Float)
    info1 = Column(String(150))
    info2 = Column(String(150))


class SanCai(db.Model):
    __tablename__ = "san_cai"
    title = Column(String(20), primary_key=True, unique=True)
    cgy1 = Column(String(500))
    jx = Column(String(10))
    info = Column(String(900))
    jcy = Column(String(500))
    jx1 = Column(String(50))
    cgy = Column(String(500))
    jx2 = Column(String(10))
    rjgx = Column(String(500))
    jx3 = Column(String(10))
    xg = Column(String(500))


class Shi(db.Model):
    __tablename__ = "shi"
    shichen = Column(String(20), primary_key=True, unique=True)
    weight = Column(Float)
    info1 = Column(String(200))
    info2 = Column(String(50))
    info3 = Column(String(200))
    info4 = Column(String(200))
    info5 = Column(String(200))
    info6 = Column(String(50))
    xinxi = Column(Text, nullable=False)


class Smth(db.Model):
    __tablename__ = "smth"
    id = Column(Integer, primary_key=True, unique=True)
    ri = Column(String(10), nullable=False)
    shi = Column(String(10), nullable=False)
    info1 = Column(String(300), nullable=False)
    info2 = Column(String(300), nullable=False)


class WuXing(db.Model):
    __tablename__ = "wuxing"
    wx = Column(String(15), nullable=False, primary_key=True, unique=True)
    tnwx = Column(String(30), nullable=False)
    ynwx = Column(String(40), nullable=False)
    skzhyj = Column(Text, nullable=False)
    wxzx = Column(Text, nullable=False)
    szwh = Column(Text, nullable=False)
    hywx = Column(Text, nullable=False)


class Yue(db.Model):
    __tablename__ = "yue"
    id = Column(Integer, primary_key=True, unique=True)
    di_zhi = Column(String(10), unique=True)
    weight = Column(Float)
    info1 = Column(String(200))
    info2 = Column(String(200))
    poem = Column(String(200))
    info3 = Column(String(100))
    ming_gong = Column(String(300))
