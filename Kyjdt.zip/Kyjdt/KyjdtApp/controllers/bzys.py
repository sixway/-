import uuid, datetime, random
from flask import render_template, request, make_response, redirect, url_for

from KyjdtApp.forms.bzysform import OrderPayForm
from KyjdtApp.models.OrderPay import OrderForm
from KyjdtApp.models.QiMenDunJia import LiuShiJiaZi, WuXing, Yue, BiHua, SanCai, EightOne, MiaoShu, FaCheng, Smth, Ri, \
    Shi, ChengGu, Dsdp
from . import web
from ..extensions import db


@web.route("/bzys", methods=["GET", "POST"])
def bzys_index():
    cid = request.args.get('cid', 0)
    domain = request.headers.get('Domain_name', '0')
    expire_date = datetime.datetime.now() + datetime.timedelta(days=365)
    resp = make_response(render_template("product/bzys.html", cid=cid))
    if not request.cookies.get('Kyjdt', ''):
        resp.set_cookie('Kyjdt', str(uuid.uuid4()), expires=expire_date)
    return resp


@web.route("/bzys_pay", methods=["GET", "POST"])
def bzys_pay():
    form = OrderPayForm(request.form)
    if request.method == 'POST' and form.validate():
        data = form.data
        ua = request.headers.get('User-Agent', '')
        ip = request.headers.get('Remote_addr', '')
        cookies = request.cookies.get('Kyjdt', '')
        order_num = "D" + datetime.datetime.now().strftime('%Y%m%d%H%M%S') + str(random.randint(100000, 999999)) + '_1001'
        data['ua'] = ua
        data['ip'] = ip
        data['cookies'] = cookies
        data["order_num"] = order_num
        if data["birth_time"] == -1:
            data["birth_time_final"] = random.randint(0, 23)
        else:
            data["birth_time_final"] = data["birth_time"]
        with db.auto_commit():
            orderform = OrderForm()
            orderform.set_attrs(data)
            db.session.add(orderform)
        return render_template("product/bzys_pay.html", data=data)
    else:
        return render_template("error/500.html")


@web.route("/bzys_result/<order_num>")
def bzys_result(order_num=''):
    SHICHEN = {0:u'子', 1:u'丑', 2:u'丑', 3:u'寅', 4:u'寅', 5:u'卯', 6:u'卯', 7:u'辰', 8:u'辰', 9:u'巳', 10:u'巳',
               11:u'午', 12:u'午', 13:u'未', 14:u'未', 15:u'申', 16:u'申', 17:u'酉', 18:u'酉', 19:u'戌',20:u'戌',
               21:u'亥',22:u'亥',23:u'子'}
    SEASONS = {1:u"春",2:u"春",3:u"春",4:u"夏",5:u"夏",6:u"夏",7:u"秋",8:u"秋",9:u"秋",10:u"冬",11:u"冬",12:u"冬"}
    CHINA_ZODIAC = [u'鼠',u'牛',u'虎',u'兔',u'龙',u'蛇',u'马',u'羊',u'猴',u'鸡',u'狗',u'猪']
    order_info = OrderForm.query.filter_by(order_num=order_num).first()
    if order_info.birth_time == -1:
        birth_time = order_info.birth_time_final
        bt = "未知"
        ns = "未知"
    else:
        birth_time = order_info.birth_time
        bt = int(birth_time)
        ns = SHICHEN[bt]
    username = order_info.user_name
    birth_date = str(order_info.birth_date).split("-")
    birth_date_lunar = order_info.birth_date_lunar.split("-")
    wx = order_info.wuxing
    zodiac = CHINA_ZODIAC[(int(birth_date_lunar[0])-1900)%12]
    season = SEASONS[int(birth_date_lunar[1])]
    wx_wang = ""
    wx_que = ""
    for item in u"金木水火土":
        if wx.count(item) >= 3:
            wx_wang = item + u'旺'
        if wx.count(item) == 0:
            wx_que = u'缺' + item
    bazi_list = [order_info.bazi[:2], order_info.bazi[2:4], order_info.bazi[4:6], order_info.bazi[6:]]
    hua_jia_zi_list = LiuShiJiaZi.query.filter(LiuShiJiaZi.hua_jia_zi.in_(bazi_list)).all()
    hua_jia_zi_list = [next(hua for hua in hua_jia_zi_list if hua.hua_jia_zi == bazi) for bazi in bazi_list]
    user_info = {
        "name":username,
        "gn":birth_date[0],
        "gy":birth_date[1],
        "gr":birth_date[2],
        "gs":bt,
        "nn":birth_date_lunar[0],
        "ny":birth_date_lunar[1],
        "nr":birth_date_lunar[2],
        "ns":ns,
        "bzn":bazi_list[0],
        "bzy":bazi_list[1],
        "bzr":bazi_list[2],
        "bzs":bazi_list[3],
        "wxn":wx[:2],
        "wxy":wx[2:4],
        "wxr":wx[4:6],
        "wxs":wx[6:],
        "nyn":hua_jia_zi_list[0].na_yin,
        "nyy":hua_jia_zi_list[1].na_yin,
        "nyr":hua_jia_zi_list[2].na_yin,
        "nys":hua_jia_zi_list[3].na_yin,
        "gender":order_info.gender
    }
    wuxing = WuXing.query.filter_by(wx=wx[4]).first()
    info = u"本命属%s，%s命。%s；日主天干为%s，生于%s季。（同类%s；异类%s。）" % (
        zodiac, hua_jia_zi_list[0].na_yin, wx_wang+wx_que, wx[4], season, wuxing.tnwx, wuxing.ynwx)
    MingGong = ["寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥", "子", "丑"]
    y_pos = MingGong.index(bazi_list[1][-1])+1
    s_pos = MingGong.index(bazi_list[3][-1])+1
    if y_pos + s_pos >= 14:
        id = 26 - (y_pos+s_pos)
    else:
        id = 14 - (y_pos+s_pos)
    minggong = Yue.query.filter_by(id=id).first()

    DoubleName = ["欧阳", "太史", "端木", "上官", "司马", "东方", "独孤", "南宫", "万俟",
                  "闻人", "夏侯", "诸葛", "尉迟", "公羊", "赫连", "澹台", "皇甫", "宗政",
                  "濮阳", "公冶", "太叔", "申屠", "公孙", "慕容", "仲孙", "钟离", "长孙",
                  "宇文", "司徒", "鲜于", "司空", "闾丘", "子车", "亓官", "司寇", "巫马",
                  "公西", "颛孙", "壤驷", "公良", "漆雕", "乐正", "宰父", "谷梁", "拓跋",
                  "夹谷", "轩辕", "令狐", "段干", "百里", "呼延", "东郭", "南门", "羊舌",
                  "微生", "公户", "公玉", "公仪", "梁丘", "公仲", "公上", "公门", "公山",
                  "公坚", "左丘", "公伯", "西门", "公祖", "第五", "公乘", "贯丘", "公皙",
                  "南荣", "东里", "东宫", "仲长", "子书", "子桑", "即墨", "达奚", "褚师"]
    nums = []
    for zi in username:
        try:
            bi_hua = BiHua.query.filter(BiHua.han_zi.like('%'+ zi +'%')).first()
            num = bi_hua.num
        except:
            num = 9
        nums.append(num)
    tiange = renge = dige = 0
    for i in DoubleName:
        if i == username[:2] and len(username) > 2:
            tiange = nums[0] + nums[1]
            renge = nums[1] + nums[2]
            if len(username) == 3:
                dige = nums[2] + 1
            else:
                for i1 in nums[2:]:
                    dige += i1
        elif i == username[:2] and len(username) == 2:
            tiange = nums[0] + nums[1]
            renge = nums[1] + 9
            dige = 9
    tiange = nums[0] + 1
    renge = nums[0] + nums[1]
    if len(username) == 2:
        dige = nums[1] + 1
    else:
        for i in nums[1:]:
            dige += i
    SCWX = {0: u"水", 1: u"木", 2: u"木", 3: u"火", 4: u"火", 5: u"土", 6: u"土", 7: u"金", 8: u"金", 9: u"水"}
    title = SCWX[tiange % 10] + SCWX[renge % 10] + SCWX[dige % 10]
    # 运气影响及三才吉凶
    sancai = SanCai.query.filter_by(title=title).first()
    zongge = EightOne.query.filter_by(id=sum(nums)).first()
    # 称骨论命
    miaoshu_num = hua_jia_zi_list[0].miao_shu + hua_jia_zi_list[1].miao_shu + hua_jia_zi_list[2].miao_shu + hua_jia_zi_list[3].miao_shu
    miaoshu = MiaoShu.query.filter_by(num=miaoshu_num).first()
    facheng_weight = int((hua_jia_zi_list[0].fa_cheng_shu + hua_jia_zi_list[1].fa_cheng_shu + hua_jia_zi_list[2].fa_cheng_shu + hua_jia_zi_list[3].fa_cheng_shu) * 10)
    facheng = FaCheng.query.filter_by(weight=facheng_weight).first()
    # 三命通会
    yue = Yue.query.filter_by(id=birth_date_lunar[1]).first()
    ri = Ri.query.filter_by(id=birth_date_lunar[2]).first()
    shi = Shi.query.filter_by(shichen=SHICHEN[int(birth_time)]).first()
    smth = Smth.query.filter_by(ri=bazi_list[2], shi=bazi_list[3]).first()
    chenggu_weight = int((hua_jia_zi_list[0].cheng_gu + yue.weight + ri.weight + shi.weight) * 10)
    chenggu = ChengGu.query.filter_by(weight=chenggu_weight).first()

    dsdp_id = int((order_info.birth_date - datetime.date(1900, 1, 1)).days % 9 + 1)
    dsdp = Dsdp.query.filter_by(id=dsdp_id).first()
    return render_template("product/bzys_result.html", user_info=user_info, info=info, minggong=minggong,
                           sancai=sancai, zongge=zongge, miaoshu=miaoshu, facheng=facheng, yue=yue, ri=ri, shi=shi,
                           smth=smth, chenggu=chenggu, dsdp=dsdp, hua_jia_zi_list=hua_jia_zi_list)


@web.route("/order", methods=["GET", "POST"])
def userorder():

    return render_template("product/order.html")


@web.route("/order_help")
def order_help():
    return render_template("product/order_help.html")