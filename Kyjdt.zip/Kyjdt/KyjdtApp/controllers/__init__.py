from flask import Blueprint, url_for


web = Blueprint('web', __name__, template_folder='templates')

from KyjdtApp.controllers import main
from KyjdtApp.controllers import bzys